package controllers;

import java.util.List;

import models.Status;
import models.TipoImovel;
import play.mvc.Controller;

public class TipoImoveis extends Controller{

	public static void form() {
		render();
	}
	
	public static void listar(String termo) {
	
		  List<TipoImovel> tiposImoveis = null;
	        if (termo == null) {
	            tiposImoveis = TipoImovel.find("status <> ?1", Status.INATIVO).fetch();
	        } else {
	            tiposImoveis = TipoImovel.find("lower(descricao) like ?1 and status <> ?2",
	                                        "%" + termo.toLowerCase() + "%",
	                                        Status.INATIVO).fetch();
	        }
	        render(tiposImoveis, termo);
	}
	
	 public static void detalhar(Long id) {
	        TipoImovel tipoImovel = TipoImovel.findById(id);
	        render(tipoImovel);
	    }
	    
	    public static void editar(Long id) {
	        TipoImovel tipoImovel = TipoImovel.findById(id);
	        renderTemplate("TipoImoveis/form.html", tipoImovel);
	    }
	    
	    public static void salvar(TipoImovel tipoImovel) {
	        tipoImovel.save();
	        detalhar(tipoImovel.id);
	    }
	    
	    public static void remover(Long id) {
	        TipoImovel tipoImovel = TipoImovel.findById(id);
	        if (tipoImovel != null) {
	            tipoImovel.status = Status.INATIVO;
	            tipoImovel.save();
	        }
	        listar(null);
	    }
	
}
