package controllers;

import java.util.List;

import models.Imovel;
import models.Status;
import models.TipoImovel;
import play.mvc.Controller;

public class Imoveis extends Controller {

	public static void form() {
		List<TipoImovel> tiposImoveis = TipoImovel.find("status <> ?1", Status.INATIVO).fetch();
		render(tiposImoveis);
	}

	public static void listar(String termo) {
		List<Imovel> imoveis = null;
		if (termo == null) {
			imoveis = Imovel.findAll();
		} else {
			imoveis = Imovel
					.find("lower(bairro) like ?1 or lower(codigoAnuncio) like ?1", "%" + termo.toLowerCase() + "%")
					.fetch();
		}
		render(imoveis, termo);
	}

	public static void detalhar(Long id) {
		Imovel imovel = Imovel.findById(id);
		render(imovel);
	}

	public static void editar(Long id) {
		Imovel imovel = Imovel.findById(id);
		List<TipoImovel> tiposImoveis = TipoImovel.find("status <> ?1", models.Status.INATIVO).fetch();
		renderTemplate("Imoveis/form.html", imovel, tiposImoveis);
	}

	public static void salvar(Imovel imovel) {
	    // Verificação de unicidade do código do anúncio (não pode haver dois iguais)
	    Imovel existente = Imovel.find("codigoAnuncio = ?1 and id <> ?2", imovel.codigoAnuncio, imovel.id).first();

	    if (existente != null) {
	        flash.error("Já existe um imóvel com este código de anúncio!");
	        params.flash(); // mantém os dados do formulário preenchidos

	        if (imovel.id == null) {
	            form(); // novo cadastro
	        } else {
	            editar(imovel.id); // edição
	        }

	        return; // Impede que continue e salve o imóvel
	    }

	    imovel.save();
	    flash.success("Imóvel salvo com sucesso!");
	    detalhar(imovel.id);
	}


	public static void remover(Long id) {
		Imovel imovel = Imovel.findById(id);
		if (imovel != null) {
			imovel.delete();
		}
		listar(null);
	}

}
