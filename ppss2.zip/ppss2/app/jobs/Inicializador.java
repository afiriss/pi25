package jobs;
import models.Imovel;
import models.TipoImovel;
import play.jobs.Job;
import play.jobs.OnApplicationStart;

@OnApplicationStart
public class Inicializador extends Job {
    
    @Override
    public void doJob() throws Exception {
        if (TipoImovel.count() == 0) {
            TipoImovel casa = new TipoImovel("CASA");
            TipoImovel apartamento = new TipoImovel("APARTAMENTO");
            TipoImovel chale = new TipoImovel("CHALÉ");
            casa.save();
            apartamento.save();
            chale.save();
        }

        if (Imovel.count() == 0) {
            TipoImovel casa = TipoImovel.find("byDescricao", "CASA").first();
            TipoImovel apartamento = TipoImovel.find("byDescricao", "APARTAMENTO").first();

            Imovel imovel1 = new Imovel("COD123", "Centro", 3, 100.0, 50.0, casa);
            Imovel imovel2 = new Imovel("COD456", "Vila Nova", 2, 75.0, 10.0, apartamento);
            imovel1.save();
            imovel2.save();
        }
    }
}